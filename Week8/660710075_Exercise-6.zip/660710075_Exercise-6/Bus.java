public class Bus extends Vehicles
{
    public Bus(double fuelQuantity, double fuelConsumption){
        setFuelQuantity(fuelQuantity);
        setCurrentFuel(fuelQuantity);
        setFuelConsumption(fuelConsumption);
    }
}
